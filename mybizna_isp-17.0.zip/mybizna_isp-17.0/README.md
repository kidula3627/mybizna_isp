# mybizna_isp

A system for auto-billing clients with ability to enable and disable on payment and expiry respectively. The system works by integrating Odoo ERP with MPESA by interpreting message to payment and auto reconciling unpaid invoices with the payment transaction.

It can work offline or online and does not need complex APIs integration for it to work. It use PlaySMS, Odoo, Freeradius and Mikrotik API.